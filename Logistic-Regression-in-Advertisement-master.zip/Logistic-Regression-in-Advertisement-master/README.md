# Logistic-Regression-in-Advertisement
Predicting if the customer will click on the advertisement displayed on Facebook or not
